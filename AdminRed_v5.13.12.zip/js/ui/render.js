/**
 * ui/render.js — Render principal de tablas/tarjetas de clientes y vistas.
 * Depende de calculations.js (usa funciones de cálculo).
 */
RN.render = RN.render || {};

/** Escape HTML. */
RN.render.esc = function (s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
};

/** v5.13.5 (ISSUE #26): Escape de un string para atributos onclick="...('STR')".
 * Escapa comillas simples (contexto JS) y dobles (contexto HTML) para evitar
 * que nombres con " o ' rompan el HTML. */
RN.render.escAttr = function (s) {
  return String(s == null ? '' : s)
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/"/g, '"');
}

// v5.13.9 (DUP-2): Badge unificado de tipo de pago para cobros del historial.
// Centraliza el patron repetido en render.realizados(), render.reportes() y recibo._html().
// Devuelve HTML con badge consistente: Completo / Parcial (falta) / Con vuelto.
RN.render.badgeTipoPago = function (h) {
  var t = h.tipoPago || 'completo';
  if (t === 'parcial') {
    return '<span class="badge parcial">Parcial \u00b7 Falta ' + RN.calc.formatCUP(h.falta || 0) + '</span>';
  }
  if (t === 'excedente') {
    return '<span class="badge paid">Con vuelto ' + RN.calc.formatCUP(h.excedente || 0) + '</span>';
  }
  return '<span class="badge paid">Completo</span>';
};

/** Badge de estado de cliente. */
RN.render.badgeEstado = function (estado) {
  const map = { ok: ['ok', 'Al día'], warn: ['warn', 'Por vencer'], due: ['due', 'Atrasado'], paid: ['paid', 'Pagado'], parcial: ['parcial', 'Pago parcial'], 'por-iniciar': ['por-iniciar', 'Por iniciar'], inactivo: ['muted', 'Inactivo'] };
  const [cls, txt] = map[estado] || ['muted', estado];
  return `<span class="badge ${cls}">${txt}</span>`;
};

/** Busca plan por id. v5.8.8: el personalizado muestra sus megas si los tiene. */
RN.render.nombrePlan = function (cliente) {
  if (cliente.planId) {
    const p = RN.state.planes.find(pl => pl.id === cliente.planId);
    if (p) return `${RN.render.esc(p.nombre)} · ${p.megas || '?'}M`;
  }
  const m = RN.calc.getMegasCliente(cliente);
  return m > 0 ? `Personalizado · ${m}M` : 'Personalizado';
};

/** Alterna la expansión de una tarjeta accordion (cintilla colapsable). */
RN.render.toggleCard = function (cardId) {
  var el = document.getElementById(cardId);
  if (!el) return;
  el.classList.toggle('open');
};

/**
 * v5.12.6 — Compara dos direcciones IP (IPv4) en orden natural numérico.
 * Convierte cada octeto a número para que 10.10.10.2 vaya antes que
 * 10.10.10.10 (a diferencia del orden alfabético de strings).
 * Soporta IPs parciales (1, 2 o 3 octetos) comparando octeto a octeto;
 * los octetos ausentes se tratan como 0.
 * @returns {number} -1, 0, 1 (estilo sort)
 */
RN.render.compararIP = function (a, b) {
  var pa = String(a || '').split('.');
  var pb = String(b || '').split('.');
  var len = Math.max(pa.length, pb.length);
  for (var i = 0; i < len; i++) {
    var na = parseInt(pa[i], 10);
    var nb = parseInt(pb[i], 10);
    if (isNaN(na)) na = 0;
    if (isNaN(nb)) nb = 0;
    if (na !== nb) return na - nb;
  }
  return 0;
};

/**
 * v5.12.6 — Compara dos clientes por IP (orden natural de IP).
 * Los clientes SIN ip van al final. Entre los que no tienen ip, se
 * ordenan por nombre (ascendente) como criterio secundario estable.
 * @returns {number} -1, 0, 1 (estilo sort)
 */
RN.render.compararClientePorIP = function (a, b) {
  var aIp = a && a.ip ? String(a.ip).trim() : '';
  var bIp = b && b.ip ? String(b.ip).trim() : '';
  if (!aIp && !bIp) {
    // Sin IP ambos: orden por nombre
    return String(a.nombre || '').localeCompare(String(b.nombre || ''), 'es');
  }
  if (!aIp) return 1;   // a sin IP → va al final
  if (!bIp) return -1;  // b sin IP → va al final
  return RN.render.compararIP(aIp, bIp);
};

/** Render completo: refresca todas las vistas. */
RN.render.todo = function () {
  ['dashboard', 'clientes', 'cobros', 'realizados', 'inversion', 'inventario', 'gastos', 'reportes', 'calendario', 'descuentos', 'salud'].forEach(v => {
    RN.render.vista(v);
  });
  RN.config.rellenarForm();
  // v5.12.7: refrescar el indicador visual de estado de la tasa en Ajustes
  if (RN.tasaAviso) RN.tasaAviso.actualizarIndicador();
  RN.storageFile.actualizarStatus();
};

/** Render de una vista específica. */
RN.render.vista = function (view) {
  switch (view) {
    case 'dashboard': RN.render.dashboard(); break;
    case 'clientes': RN.render.clientes(); break;
    case 'cobros': RN.render.cobros(); break;
    case 'realizados': RN.render.realizados(); break;
    case 'inversion': RN.render.inversion(); break;
    case 'inventario': RN.render.inventario(); break;
    case 'gastos': RN.render.gastos(); break;
    case 'reportes': RN.render.reportes(); break;
    case 'calendario': RN.calendario && RN.calendario.render(); break;
    case 'descuentos': RN.descuentosView && RN.descuentosView.render(); break;
    case 'salud': RN.salud && RN.salud.render(); break;
  }
};

// ---------- DASHBOARD ----------

/**
 * v5.13.6 (CODE-6): Descripción reutilizable del paquete del proveedor
 * en formato "Mm × P CUP/M". Evita duplicar esta construcción de string
 * en el KPI "Costo del paquete" y en el widget del proveedor.
 * @returns {string} Descripción del paquete o '' si no hay config.
 */
RN.render.descPaquete = function () {
  var m = RN.state.config.proveedorMegas || 0;
  var p = RN.state.config.proveedorPrecioMega || 0;
  return m + 'M × ' + p + ' CUP/M';
};

/**
 * v5.12.6 — Construye el texto "sub" de una tarjeta KPI con el equivalente
 * en USD (en letras pequeñas) cuando hay tasa configurada. Si ya hay un sub
 * textual, lo antepone. Si no hay tasa, devuelve el sub original.
 * @param {number} cup - monto en CUP
 * @param {string} subTxt - texto descriptivo original (opcional)
 * @returns {string} HTML para el div .sub
 */
RN.render.subUSD = function (cup, subTxt) {
  var usd = RN.moneda.aUSD(cup);
  var parts = [];
  if (subTxt) parts.push(RN.render.esc(subTxt));
  // v5.13.6 (UI-6): envolver el USD en un badge visual distintivo.
  if (usd) parts.push('<span class="usd-badge">≈ ' + usd + ' USD</span>');
  return parts.join(' ');
};

/**
 * v5.12.6 — Genera el HTML de la barra horizontal animada de recuperación
 * de la inversión, con los datos resumidos (invertido, recuperado, %, faltante).
 * Reutiliza los estilos .recup-* definidos en styles.css.
 * @returns {string} HTML del bloque
 */
RN.render.barraRecuperacion = function (inv, rec, pctParam) {
  // v5.13.6 (DUP-3): acepta valores pre-calculados para evitar recalcular.
  // Si no se pasan, calcula aquí (compatibilidad con llamadas externas).
  var invertido = (inv !== undefined) ? inv : RN.investment.totalInvertido();
  var recuperado = (rec !== undefined) ? rec : RN.investment.totalRecuperado();
  var pct = (pctParam !== undefined) ? pctParam : RN.investment.porcentajeRecuperacion();
  // Limitar el ancho visual a 100% aunque el % supere 100 (recuperada)
  var pctVisual = Math.min(100, Math.max(0, pct));
  var faltante = Math.max(0, +(invertido - recuperado).toFixed(2));

  // Color de la barra según progreso
  var cls = 'recup-green';
  if (pct >= 100) cls = 'recup-green';
  else if (pct >= 60) cls = 'recup-green';
  else if (pct >= 30) cls = 'recup-amber';
  else cls = 'recup-red';

  var estadoTxt;
  if (invertido <= 0) estadoTxt = '<span class="muted">Sin inversiones registradas</span>';
  else if (pct >= 100) estadoTxt = '<span style="color:var(--green)">✓ Inversión recuperada</span>';
  else estadoTxt = '<span class="muted">En proceso de recuperación</span>';

  // v5.13.4: Bug #17 - Advertencia visible cuando no hay precio de proveedor
  // configurado. Sin ese dato, el margen y el % de recuperacion se calculan
  // asumiendo costo 0, por lo que estan inflados. La auditoria v5.13.0 (Bug #17)
  // pedia que la UI advirtiera al usuario; la funcion costoMegaConfigurado()
  // ya existia desde v5.13.1 pero no se usaba en la UI.
  var sinCosto = !RN.investment.costoMegaConfigurado();

  var html = '';
  html += '<div class="recup-card">';
  html += '  <div class="recup-head">';
  html += '    <div class="recup-titulo"><span class="recup-ico">📈</span> <strong>Recuperación de la inversión</strong></div>';
  html += '    <div class="recup-pct"><strong>' + pct + '%</strong>' + (sinCosto ? ' <span class="muted" style="font-size:11px">(estimado)</span>' : '') + '</div>';
  html += '  </div>';
  html += '  <div class="recup-bar"><div class="recup-fill ' + cls + '" data-pct="' + pctVisual + '" style="width:0%"></div></div>';
  html += '  <div class="recup-datos">';
  html += '    <div class="recup-dato"><span class="muted">Invertido</span><strong>' + RN.calc.formatCUP(invertido) + '</strong></div>';
  html += '    <div class="recup-dato"><span class="muted">Recuperado</span><strong style="color:var(--green)">' + RN.calc.formatCUP(recuperado) + '</strong></div>';
  html += '    <div class="recup-dato"><span class="muted">Por recuperar</span><strong style="color:var(--danger)">' + RN.calc.formatCUP(faltante) + '</strong></div>';
  html += '  </div>';
  html += '  <div class="recup-estado">' + estadoTxt + '</div>';
  if (sinCosto) {
    html += '  <div style="margin-top:10px;padding:10px 12px;border-radius:8px;background:rgba(245,158,11,0.12);border:1px solid rgba(245,158,11,0.35);font-size:12px;color:#e6a700">';
    html += '    \u26a0\ufe0f El % de recuperación está <strong>inflado</strong>: no hay precio de proveedor por mega configurado, por lo que el margen se calcula asumiendo costo 0. Configura el precio del mega en Ajustes \u2192 Proveedor para ver la recuperación real.';
    html += '  </div>';
  }
  html += '</div>';
  return html;
};

/**
 * v5.12.6 — Dispara la animación de las barras de recuperación presentes
 * en el DOM. Busca todos los .recup-fill con data-pct y anima el ancho
 * desde 0% hasta el valor objetivo usando requestAnimationFrame.
 */
RN.render.animarBarrasRecuperacion = function () {
  var barras = document.querySelectorAll('.recup-fill[data-pct]');
  barras.forEach(function (barra) {
    var objetivo = parseFloat(barra.getAttribute('data-pct')) || 0;
    if (objetivo <= 0) { barra.style.width = '0%'; return; }
    var inicio = null;
    var duracion = 900; // ms
    function paso(ts) {
      if (!inicio) inicio = ts;
      var progreso = Math.min(1, (ts - inicio) / duracion);
      // ease-out cubic
      var eased = 1 - Math.pow(1 - progreso, 3);
      barra.style.width = (objetivo * eased) + '%';
      if (progreso < 1) requestAnimationFrame(paso);
      else barra.style.width = objetivo + '%';
    }
    requestAnimationFrame(paso);
  });
};

RN.render.dashboard = function () {
  const cont = document.getElementById('kpi-dashboard');
  if (!cont) return;
  // v5.13.6 (UI-5): mostrar el mes operativo visible en el header del panel.
  // Si el mes operativo (RN.state.mesActual) difiere del mes real del reloj,
  // se senala con un aviso de "mes cerrado".
  const mesOper = document.getElementById('dashboard-mes');
  if (mesOper) {
    const mesAct = RN.calc.mesActualStr();
    const mesReal = RN.calc.mesRealStr();
    if (mesAct !== mesReal) {
      mesOper.innerHTML = '⚠ Mes operativo: <strong>' + RN.calc.mesTexto(mesAct) + '</strong>';
      mesOper.className = 'mes-badge mes-cerrado';
    } else {
      mesOper.innerHTML = 'Mes: <strong>' + RN.calc.mesTexto(mesAct) + '</strong>';
      mesOper.className = 'mes-badge muted';
    }
  }
  const cob = RN.calc.cobranzaMes();
  const ingresos = RN.calc.ingresosMes();
  const gastos = RN.calc.gastosMes();
  const utilidad = ingresos - gastos;
  const esperado = RN.calc.ingresoEsperadoMes();
  // v5.13.6 (BUG-5): tasa de cobro basada en ingresos de SERVICIO del mes
  // (sin equipo ni mora de otros meses) para que no supere 100% de forma
  // enga\u00f1osa. Antes usaba ingresosMes() que incluye h.montoEquipo.
  const ingresoServMes = RN.calc.ingresosServicioMes();
  const tasaCob = esperado ? Math.round(ingresoServMes / esperado * 100) : 0;
  // v5.13.6 (DUP-1): cachear clientesActivos() una sola vez.
  // Antes se llamaba 2 veces (aquí y en el resumen) + 1 dentro de cobranzaMes.
  const activos = RN.calc.clientesActivos();
  // v5.10.5: mora real = clientes con meses de atraso (getMora > 0).
  const morosos = activos.filter(c => RN.calc.getMora(c) > 0).length;

  const parciales = cob.parciales || 0;
  const fondoCaja = RN.calc.fondoCaja();
  // v5.12.3: costo del paquete del proveedor y ganancia bruta del mes
  const costoPaquete = RN.calc.montoPaqueteProveedor();
  const gananciaBruta = ingresos - costoPaquete;
  // v5.12.6: ganancia proyectada del mes = ingreso esperado (lo que deberían
  // pagar todos los clientes activos) − costo del paquete del proveedor.
  const gananciaProyectada = esperado - costoPaquete;
  // v5.10.4: KPIs clicables. Cobranza, Clientes morosos y Fondo de caja
  // abren ventanas superpuestas al hacer click. Las demas no son clicables.
  // v5.12.6 (propuesta A): orden lógico — esperado antes que real.
  //   Ingresos del mes → Costo del paquete → Ganancia proyectada
  //   → Ganancia del mes (real cobrada) → Utilidad neta → ...
  // v5.12.6: todas las tarjetas con monto CUP muestran su equivalente en USD
  // (en letras pequeñas) cuando hay tasa configurada.
  const kpis = [
    { label: 'Ingresos del mes', value: RN.calc.formatCUP(ingresos), sub: RN.render.subUSD(ingresos), cls: 'green' },
    { label: 'Costo del paquete', value: RN.calc.formatCUP(costoPaquete), sub: costoPaquete > 0 ? RN.render.subUSD(costoPaquete, RN.render.descPaquete()) : 'Sin paquete configurado', cls: 'amber' },
    { label: 'Ganancia proyectada del mes', value: RN.calc.formatCUP(gananciaProyectada), sub: RN.render.subUSD(gananciaProyectada, 'Ingreso esperado − Costo del paquete'), cls: gananciaProyectada >= 0 ? 'green' : 'red' },
    { label: 'Ganancia del mes', value: RN.calc.formatCUP(gananciaBruta), sub: RN.render.subUSD(gananciaBruta, 'Cobrado − Costo del paquete'), cls: gananciaBruta >= 0 ? 'blue' : 'red' },
    { label: 'Utilidad neta', value: RN.calc.formatCUP(utilidad), sub: RN.render.subUSD(utilidad, 'Ingresos − Gastos'), cls: utilidad >= 0 ? 'blue' : 'red' },
    { label: 'Cobranza', value: cob.pagaron + '/' + cob.total, sub: 'Faltan ' + cob.faltan + ' clientes' + (parciales ? ' · ' + parciales + ' parcial' : '') + ' — toca para ver corte vigente', cls: 'blue', click: 'RN.cobranza.abrir()' },
    { label: 'Tasa de cobro', value: tasaCob + '%', sub: 'Servicio cobrado sobre lo esperado', cls: tasaCob >= 70 ? 'green' : (tasaCob >= 40 ? 'amber' : 'red') },
    { label: 'Clientes morosos', value: morosos, sub: morosos ? 'Atrasados — toca para ver detalles' : 'Ninguno atrasado', cls: morosos ? 'red' : 'green', click: 'RN.mora.abrir()' },
    { label: 'Fondo de caja', value: RN.calc.formatCUP(fondoCaja), sub: RN.render.subUSD(fondoCaja, 'Ganancia acumulada — toca para retirar'), cls: fondoCaja > 0 ? 'green' : (fondoCaja < 0 ? 'red' : 'muted'), click: 'RN.caja.extraer()' }
  ];
  cont.innerHTML = kpis.map(k => {
    const attr = k.click ? ` role="button" tabindex="0" onclick="${k.click}" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();${k.click}}" class="kpi ${k.cls} kpi-click"` : ` class="kpi ${k.cls}"`;
    return `<div${attr}><div class="label">${k.label}</div><div class="value">${k.value}</div><div class="sub">${k.sub}</div></div>`;
  }).join('');
  // v5.13.6 (DUP-3): cachear funciones de inversión una sola vez.
  // Antes totalInvertido() se llamaba 4x, totalRecuperado() 3x y
  // porcentajeRecuperacion() 2x (cada una recalcula internamente).
  const totalInv = RN.investment.totalInvertido();
  const recInv = RN.investment.totalRecuperado();
  const pctRecup = totalInv ? +(recInv / totalInv * 100).toFixed(1) : 0;
  const res = document.getElementById('dashboard-resumen');
  if (res) {
    res.innerHTML = `
      <div class="flex wrap" style="gap:24px">
        <div><strong>Clientes activos:</strong> ${activos.length}</div>
        <div><strong>Planes:</strong> ${RN.state.planes.length}</div>
        <div><strong>Inversión recuperada:</strong> ${pctRecup}%${RN.investment.costoMegaConfigurado() ? '' : ' <span class="muted" style="font-size:12px">(estimado, sin costo de proveedor)</span>'}</div>
        <div><strong>Predicción próximo mes:</strong> ${RN.calc.formatCUP(RN.calc.prediccionIngresos())}</div>
      </div>`;
  }

  // v5.12.6: Barra animada de recuperación de la inversión.
  // Se oculta la card completa si no hay inversiones registradas.
  const recupEl = document.getElementById('dashboard-recuperacion');
  const recupCard = document.getElementById('card-recuperacion');
  if (recupEl && recupCard) {
    if (totalInv > 0) {
      recupCard.style.display = '';
      recupEl.innerHTML = RN.render.barraRecuperacion(totalInv, recInv, pctRecup);
    } else {
      // v5.13.6 (UI-3): estado vacío en vez de ocultar la card completamente.
      recupCard.style.display = '';
      recupEl.innerHTML = '<div class="acc-empty"><div class="icon">💰</div>No hay inversiones registradas aún. <button class="btn sm primary" style="margin-top:8px" onclick="RN.investment.abrirModal()">Registrar inversión</button></div>';
    }
  }

  // Widget: Pago del servicio de internet al proveedor (v5.8.6)
  const prov = document.getElementById('dashboard-proveedor');
  if (prov) {
    const cfg = RN.state.config;
    // v5.13.6 (DUP-2): reutilizar costoPaquete ya calculado arriba.
    const montoPaquete = costoPaquete;
    const pagoMes = RN.calc.pagoProveedorMes();
    const tieneConfig = montoPaquete > 0 || cfg.proveedorInternet;
    let html = '<div class="prov-widget-head">📡 <strong>Servicio de internet</strong> <span class="muted" style="font-size:11px;font-weight:400">(gestiona y paga aquí)</span></div>';
    if (cfg.proveedorInternet) {
      html += '<div class="prov-widget-row"><span class="muted">Proveedor:</span> <strong>' + RN.render.esc(cfg.proveedorInternet) + '</strong></div>';
    }
    if (cfg.proveedorMegas > 0 || cfg.proveedorPrecioMega > 0) {
      html += '<div class="prov-widget-row"><span class="muted">Paquete:</span> <strong>' + (cfg.proveedorMegas || 0) + ' Megas × ' + (cfg.proveedorPrecioMega || 0) + ' CUP/M = ' + RN.calc.formatCUP(montoPaquete) + '</strong></div>';
    }
    if (pagoMes) {
      const fecha = pagoMes.fecha ? new Date(pagoMes.fecha).toLocaleDateString('es-CU') : '';
      // v5.12.3: Detectar si el paquete config cambio desde el ultimo pago.
      // Mostrar el paquete actual (config) claramente y senalar la diferencia.
      const megasPagados = +pagoMes.megas || 0;
      const precioPagado = +pagoMes.precioMega || 0;
      const paqueteCambio = (megasPagados !== (+cfg.proveedorMegas || 0)) || (precioPagado !== (+cfg.proveedorPrecioMega || 0));
      html += '<div class="prov-widget-row prov-paid"><span class="badge paid">✓ Pagado este mes</span> <span class="muted">' + RN.calc.formatCUP(pagoMes.monto) + ' · ' + fecha + '</span></div>';
      if (paqueteCambio) {
        html += '<div class="prov-widget-row" style="color:#e6a700"><span class="badge warn" style="margin-right:6px">Paquete actualizado</span> <span class="muted">Pagaste ' + megasPagados + 'M × ' + precioPagado + ' CUP/M. El paquete actual es ' + (cfg.proveedorMegas || 0) + 'M × ' + (cfg.proveedorPrecioMega || 0) + ' CUP/M = ' + RN.calc.formatCUP(montoPaquete) + '.</span></div>';
        html += '<div class="prov-widget-actions"><button class="btn sm primary" onclick="RN.paqueteProveedor.abrir()">Gestionar y pagar</button></div>';
      } else {
        html += '<div class="prov-widget-actions"><button class="btn sm primary" onclick="RN.paqueteProveedor.abrir()">Gestionar servicio</button></div>';
      }
    } else if (tieneConfig) {
      html += '<div class="prov-widget-row prov-due"><span class="badge due">Pendiente este mes</span> <span class="muted">' + (montoPaquete > 0 ? 'A pagar: ' + RN.calc.formatCUP(montoPaquete) : 'Configura megas y precio') + '</span></div>';
      html += '<div class="prov-widget-actions"><button class="btn sm primary" onclick="RN.paqueteProveedor.abrir()">📡 Gestionar servicio</button></div>';
    } else {
      html += '<div class="prov-widget-row"><span class="muted">Aún no has registrado el servicio de tu proveedor.</span></div>';
      html += '<div class="prov-widget-actions"><button class="btn sm primary" onclick="RN.paqueteProveedor.abrir()">📡 Registrar mi servicio</button></div>';
    }

    // Indicador de capacidad vendida vs tope (v5.8.7)
    if (cfg.proveedorMegas > 0) {
      const cap = RN.calc.estadoCapacidad();
      const cls = cap.excedido ? 'bar-red' : (cap.pct >= 80 ? 'bar-amber' : 'bar-green');
      const estadoTxt = cap.excedido
        ? '<span style="color:#c62828">⚠ Excedido</span>'
        : (cap.pct >= 80 ? '<span style="color:#e6a700">Cerca del tope</span>' : '<span style="color:#2e7d32">✓ Capacidad ok</span>');
      html += '<div class="prov-cap">';
      html += '<div class="prov-cap-label"><span class="muted">Capacidad de red</span> <strong>' + cap.vendidos + 'M vendidos / ' + cap.tope + 'M</strong> (' + cap.pct + '%) ' + estadoTxt + '</div>';
      html += '<div class="prov-cap-bar"><div class="prov-cap-fill ' + cls + '" style="width:' + (cap.pct || 1) + '%"></div></div>';
      html += '<div class="prov-cap-sub muted">' + cap.paquete + 'M paquete + ' + cap.sobreventa + 'M sobreventa = ' + cap.tope + 'M tope vendible</div>';
      html += '</div>';
    }

    // v5.12.4: Aviso de paquete pendiente para el próximo mes
    if (cfg.paquetePendiente) {
      const pp = cfg.paquetePendiente;
      const mesProx = RN.calc.mesSiguiente(RN.calc.mesActualStr());
      html += '<div class="prov-widget-row" style="color:#1565c0;border-top:1px solid var(--border);padding-top:8px;margin-top:4px">';
      html += '<span class="badge" style="background:#e3f2fd;color:#1565c0;margin-right:6px">⏳ Pendiente para ' + RN.calc.mesTexto(mesProx) + '</span>';
      html += '<span class="muted">Próximo paquete: ' + (pp.megas || 0) + 'M × ' + (pp.precioMega || 0) + ' CUP/M';
      if (pp.sobreventa !== undefined) html += ' · sobreventa ' + pp.sobreventa + 'M';
      html += '. Se aplicará al cerrar el mes.</span></div>';
    }
    prov.innerHTML = html;
  }

  // v5.10.4: El widget grande "💵 Fondo de caja" se elimina del panel principal.
  // El acceso al fondo de caja (retiros) ahora se hace desde la KPI clicable.

  // v5.12.6: disparar la animación de las barras de recuperación tras pintarlas.
  // requestAnimationFrame asegura que el DOM ya tenga width:0% antes de animar.
  if (typeof requestAnimationFrame === 'function') {
    requestAnimationFrame(RN.render.animarBarrasRecuperacion);
  } else {
    RN.render.animarBarrasRecuperacion();
  }
};

// ---------- CLIENTES ----------
RN.render.clientes = function () {
  const cont = document.getElementById('lista-clientes');
  if (!cont) return;
  const q = (document.getElementById('search-clientes') || {}).value || '';
  const fe = (document.getElementById('filter-estado') || {}).value || '';
  let lista = RN.state.clients.filter(c => {
    if (q) {
      const s = (c.nombre + ' ' + (c.telefono || '') + ' ' + (c.direccion || '') + ' ' + (c.ip || '')).toLowerCase();
      if (!s.includes(q.toLowerCase())) return false;
    }
    if (fe && RN.calc.getStatus(c) !== fe) return false;
    return true;
  });

  // v5.12.6: ordenar siempre por IP (orden natural numérico).
  // Los clientes sin IP van al final, ordenados por nombre entre sí.
  lista.sort(RN.render.compararClientePorIP);

  if (!lista.length) {
    cont.innerHTML = '<div class="acc-empty"><div class="icon">👥</div>No hay clientes. Crea el primero con "+ Nuevo cliente".</div>';
    return;
  }

  // v5.13.1: Bug #4 — mes explícito para descuentos puntuales.
  const mes = RN.calc.mesActualStr();
  cont.innerHTML = lista.map(c => {
    // v5.13.7 (DUP-2): usar resumenCliente para centralizar todos los calculos.
    const r = RN.calc.resumenCliente(c, mes);
    const estado = r.estado;
    const deuda = r.deuda;
    const neto = r.neto;
    const mora = r.mora;
    // v5.13.7 (LOG-1): si hay mora, el total incluye los meses atrasados.
    const total = mora > 0 ? r.totalDeuda : r.totalMes;
    const ipHtml = c.ip ? '<span class="acc-ip">' + RN.render.esc(c.ip) + '</span>' : '';
    const telHtml = c.telefono ? RN.render.esc(c.telefono) : '';
    const subParts = [];
    if (telHtml) subParts.push(telHtml);
    if (ipHtml) subParts.push(ipHtml);
    if (!subParts.length) subParts.push('<span class="muted">Sin datos</span>');

    return '<div class="acc-card" id="acc-cli-' + c.id + '">' +
      '<div class="acc-summary" onclick="RN.render.toggleCard(\'acc-cli-' + c.id + '\')">' +
        '<span class="acc-dot ' + estado + '"></span>' +
        '<div class="acc-summary-main">' +
          '<div class="acc-summary-name">' + RN.render.esc(c.nombre) + (mora > 0 ? ' <span class="badge due" style="font-size:10px;vertical-align:middle">' + mora + ' mes' + (mora > 1 ? 'es' : '') + '</span>' : '') + '</div>' +
          '<div class="acc-summary-sub">' + subParts.join('') + '</div>' +
        '</div>' +
        '<div class="acc-summary-total">' +
          '<div class="amt ' + (estado === 'paid' ? 'paid' : '') + '">' + (estado === 'paid' ? 'Pagado' : RN.calc.formatCUP(total)) + '</div>' +
          '<div class="lbl">' + (estado === 'paid' ? 'Este mes' : (mora > 0 ? 'Deuda total' : 'Total')) + '</div>' +
        '</div>' +
        '<span class="acc-chevron">▼</span>' +
      '</div>' +
      '<div class="acc-details">' +
        '<div class="acc-row"><span class="acc-label">Plan</span><span class="acc-value">' + RN.render.nombrePlan(c) + '<br><span class="muted" style="font-size:12px">' + RN.calc.formatCUP(RN.calc.getPrecioBase(c)) + '</span></span></div>' +
        '<div class="acc-row"><span class="acc-label">Teléfono</span><span class="acc-value">' + (c.telefono ? RN.render.esc(c.telefono) : '<span class="muted">—</span>') + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">IP / Red</span><span class="acc-value">' + (c.ip ? '<span style="font-family:monospace">' + RN.render.esc(c.ip) + '</span>' : '<span class="muted">—</span>') + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Dirección</span><span class="acc-value">' + (c.direccion ? RN.render.esc(c.direccion) : '<span class="muted">—</span>') + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Pago día</span><span class="acc-value">Día ' + (c.diaPago || 1) + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Estado</span><span class="acc-value">' + RN.render.badgeEstado(estado) + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Saldo equipo</span><span class="acc-value">' + (deuda > 0 ? '<span class="badge due">' + RN.calc.formatCUP(deuda) + '</span>' : '<span class="muted">—</span>') + '</span></div>' +
        '<div class="acc-actions">' +
          '<button class="btn sm primary" onclick="RN.modalCobro.abrir(\'' + RN.render.escAttr(c.id) + '\')">Cobrar</button>' +
          '<button class="btn sm" onclick="RN.clientHistory.abrir(\'' + c.id + '\')">Historial</button>' +
          '<button class="btn sm" onclick="RN.whatsapp.enviarRecordatorio(\'' + c.id + '\')">WhatsApp</button>' +
          '<button class="btn sm" onclick="RN.equiposRed.abrir(\'' + c.id + '\')">Equipos</button>' +
          '<button class="btn sm" onclick="RN.modalCliente.editar(\'' + c.id + '\')">Editar</button>' +
          '<button class="btn sm danger" onclick="RN.confirmDelete.cliente(\'' + c.id + '\')">🗑</button>' +
        '</div>' +
      '</div>' +
    '</div>';
  }).join('');
  // v5.13.7 (CODE-4): restaurar tarjetas que estaban abiertas antes del re-render.
  abiertas.forEach(function (cardId) {
    var el = document.getElementById(cardId);
    if (el) el.classList.add('open');
  });
};
// ---------- COBROS ----------
RN.render.cobros = function () {
  const cont = document.getElementById('lista-cobros');
  if (!cont) return;
  const q = (document.getElementById('search-cobros') || {}).value || '';
  let lista = RN.calc.clientesActivos();
  if (q) lista = lista.filter(c => c.nombre.toLowerCase().includes(q.toLowerCase()));

  if (!lista.length) {
    cont.innerHTML = '<div class="acc-empty"><div class="icon">💳</div>No hay clientes activos.</div>';
    return;
  }
  // ordenar: morosos primero
  lista.sort((a, b) => {
    const oa = { due: 0, warn: 1, parcial: 2, ok: 3, paid: 4, 'por-iniciar': 5 }[RN.calc.getStatus(a)];
    const ob = { due: 0, warn: 1, parcial: 2, ok: 3, paid: 4, 'por-iniciar': 5 }[RN.calc.getStatus(b)];
    return oa - ob;
  });

  // v5.13.1: Bug #4 — mes explícito para descuentos puntuales.
  const mes = RN.calc.mesActualStr();
  cont.innerHTML = lista.map(c => {
    // v5.13.7 (DUP-2): usar resumenCliente para centralizar calculos.
    const r = RN.calc.resumenCliente(c, mes);
    const estado = r.estado;
    const neto = r.neto;
    const cuotaEq = r.cuotaEq;
    const total = r.totalMes;
    const deuda = r.deuda;
    const mora = r.mora;
    const ipHtml = c.ip ? '<span class="acc-ip">' + RN.render.esc(c.ip) + '</span>' : '';
    const planSub = RN.render.nombrePlan(c) + ' · ' + RN.calc.formatCUP(RN.calc.getPrecioBase(c));
    const subParts = [planSub];
    if (ipHtml) subParts.push(ipHtml);

    var accBtn;
    if (estado === 'paid') {
      accBtn = '<span class="badge paid">Pagado</span>';
    } else if (estado === 'parcial') {
      accBtn = '<span class="badge parcial">Pago parcial</span> <button class="btn sm primary" onclick="RN.modalCobro.abrir(\'' + RN.render.escAttr(c.id) + '\')">Completar pago</button>';
    } else {
      accBtn = '<button class="btn sm primary" onclick="RN.modalCobro.abrir(\'' + RN.render.escAttr(c.id) + '\')">Cobrar ' + RN.calc.formatCUP(total) + '</button>';
    }

    return '<div class="acc-card" id="acc-cob-' + RN.render.escAttr(c.id) + '">' +
      '<div class="acc-summary" onclick="RN.render.toggleCard(\'acc-cob-' + RN.render.escAttr(c.id) + '\')">' +
        '<span class="acc-dot ' + estado + '"></span>' +
        '<div class="acc-summary-main">' +
          '<div class="acc-summary-name">' + RN.render.esc(c.nombre) + (mora > 0 ? ' <span class="badge due" style="font-size:10px;vertical-align:middle">Mora: ' + mora + 'm</span>' : '') + '</div>' +
          '<div class="acc-summary-sub">' + subParts.join('') + '</div>' +
        '</div>' +
        '<div class="acc-summary-total">' +
          '<div class="amt ' + (estado === 'paid' ? 'paid' : '') + '">' + (estado === 'paid' ? 'Pagado' : RN.calc.formatCUP(total)) + '</div>' +
          '<div class="lbl">' + (cuotaEq > 0 ? 'Total (+equipo)' : 'A cobrar') + '</div>' +
        '</div>' +
        '<span class="acc-chevron">▼</span>' +
      '</div>' +
      '<div class="acc-details">' +
        '<div class="acc-row"><span class="acc-label">Plan / Precio</span><span class="acc-value">' + RN.render.nombrePlan(c) + '<br><span class="muted" style="font-size:12px">Base: ' + RN.calc.formatCUP(RN.calc.getPrecioBase(c)) + '</span></span></div>' +
        '<div class="acc-row"><span class="acc-label">Teléfono</span><span class="acc-value">' + (c.telefono ? RN.render.esc(c.telefono) : '<span class="muted">—</span>') + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">IP / Red</span><span class="acc-value">' + (c.ip ? '<span style="font-family:monospace">' + RN.render.esc(c.ip) + '</span>' : '<span class="muted">—</span>') + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Día de pago</span><span class="acc-value">Día ' + (c.diaPago || 1) + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Estado</span><span class="acc-value">' + RN.render.badgeEstado(estado) + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Neto a cobrar</span><span class="acc-value">' + RN.calc.formatCUP(neto) + (cuotaEq > 0 ? ' <span class="pill">+ equipo ' + RN.calc.formatCUP(cuotaEq) + '</span>' : '') + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Saldo equipo</span><span class="acc-value">' + (deuda > 0 ? '<span class="badge due">' + RN.calc.formatCUP(deuda) + '</span>' : '<span class="muted">—</span>') + '</span></div>' +
        '<div class="acc-actions">' + accBtn + '</div>' +
      '</div>' +
    '</div>';
  }).join('');
};
// ---------- REALIZADOS (Historial de cobros) ----------
// v5.12.3: Historial agrupado por mes en cintillas colapsables.
// v5.13.9 (BUG-4): Formatear fecha de cobro en formato legible localizado
RN.render._fmtFechaCobro = function (fecha, conHora) {
  if (!fecha) return '—';
  var d = new Date(fecha);
  if (isNaN(d.getTime())) return String(fecha).slice(0, 10);
  if (conHora) {
    return d.toLocaleString('es-CU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  return d.toLocaleDateString('es-CU', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

// v5.13.9 (CODE-2/UI-3/UI-5/UI-6/UI-9/UI-10): Render de una card de cobro realizado.
// Extraido de render.realizados() para reutilizacion y legibilidad.
RN.render._cardCobroRealizado = function (h) {
  var cli = RN.calc.clientePorId(h.clienteId);
  // v5.13.9 (UI-4): Nombre clickeable para ver historial del cliente
  var sq = String.fromCharCode(0x27);
  var nombre = cli
    ? '<a href="#" onclick="RN.clientHistory.abrir(' + String.fromCharCode(0x5c) + sq + RN.render.escAttr(cli.id) + sq + String.fromCharCode(0x5c) + sq + ');return false" style="color:inherit;text-decoration:none">' + RN.render.esc(cli.nombre) + '</a>'
    : '<span class="muted">Cliente eliminado</span>';
  var total = RN.calc.totalCobro(h);

  // v5.13.9 (BUG-1): Concepto correcto segun tipo de cobro
  var concepto;
  if (h.tipo === 'venta-inventario') {
    concepto = RN.render.esc(h.concepto || 'Venta inventario');
  } else if (h.tipo === 'equipo') {
    concepto = 'Pago de equipo';
  } else {
    concepto = 'Servicio mensual' + (h.mes ? ' ' + RN.render.esc(RN.calc.mesTexto(h.mes)) : '');
  }
  if (h.montoEquipo > 0 && h.tipo === 'servicio') concepto += ' + equipo';

  // v5.13.9 (DUP-2): Badge unificado de tipo de pago
  var tipoBadge = RN.render.badgeTipoPago(h);

  // v5.13.9 (UI-10): Badge "Adelantado" si el mes de servicio es futuro
  var mesActual = RN.calc.mesActualStr();
  var esAdelantado = h.mes && h.mes > mesActual && h.tipo === 'servicio';
  var adelantadoBadge = esAdelantado
    ? ' <span class="badge" style="background:#e3f2fd;color:#1565c0;font-size:10px;vertical-align:middle">Adelantado</span>'
    : '';

  var monedaTxt = h.moneda || 'CUP';

  // v5.13.9 (UI-6): Badge de pago combinado USD+CUP
  var monedaBadge = '';
  if (h.moneda === 'MIXTO' && (h.montoPagadoUSD || 0) > 0 && (h.montoPagadoCUP || 0) > 0) {
    monedaBadge = ' <span class="pill" style="background:#e8f5e9;color:#2e7d32;font-size:10px">USD+CUP</span>';
  } else if ((h.montoPagadoUSD || 0) > 0 && (h.montoPagadoCUP || 0) > 0) {
    monedaBadge = ' <span class="pill" style="background:#e8f5e9;color:#2e7d32;font-size:10px">USD+CUP</span>';
  }

  // v5.13.9 (UI-9): Pill de recibo clickeable
  var reciboHtml = h.reciboNum
    ? '<button class="btn sm" style="padding:2px 8px" onclick="RN.recibo.ver(' + String.fromCharCode(0x5c) + sq + RN.render.escAttr(h.id) + sq + String.fromCharCode(0x5c) + sq + ')">#' + RN.render.esc(h.reciboNum) + '</button>'
    : '<span class="muted">—</span>';

  // v5.13.9 (BUG-4): Fecha localizada
  var fechaTxt = RN.render._fmtFechaCobro(h.fecha, true);

  // v5.13.9 (UI-3): data-estado segun tipo de pago
  var estadoCard = h.tipoPago === 'parcial' ? 'parcial' : 'paid';

  // v5.13.9 (UI-5): Filas de desglose servicio/equipo/mora
  var desgloseHtml = '';
  if (h.tipo === 'servicio') {
    desgloseHtml += '<div class="acc-row"><span class="acc-label">Servicio</span><span class="acc-value">' + RN.calc.formatCUP(h.monto || 0) + '</span></div>';
    if (h.montoMora && h.montoMora > 0) {
      desgloseHtml += '<div class="acc-row"><span class="acc-label">Mora</span><span class="acc-value" style="color:#c62828">' + RN.calc.formatCUP(h.montoMora) + ' (' + (h.mora || 0) + 'm)</span></div>';
    }
    if (h.descuentoRecurrente) {
      desgloseHtml += '<div class="acc-row"><span class="acc-label">Desc. recurrente</span><span class="acc-value muted">− ' + RN.calc.formatCUP(h.descuentoRecurrente) + '</span></div>';
    }
  }
  if (h.montoEquipo > 0) {
    desgloseHtml += '<div class="acc-row"><span class="acc-label">Equipo</span><span class="acc-value">' + RN.calc.formatCUP(h.montoEquipo) + '</span></div>';
  }

  return '<div class="acc-card" data-estado="' + estadoCard + '" id="acc-real-' + RN.render.escAttr(h.id) + '">' +
    '<div class="acc-summary" onclick="RN.render.toggleCard(' + String.fromCharCode(0x5c) + sq + 'acc-real-' + RN.render.escAttr(h.id) + sq + String.fromCharCode(0x5c) + sq + ')">' +
      '<span class="acc-dot ' + estadoCard + '"></span>' +
      '<div class="acc-summary-main">' +
        '<div class="acc-summary-name">' + nombre + adelantadoBadge + '</div>' +
        '<div class="acc-summary-sub">' + RN.render.esc(fechaTxt) + ' · ' + concepto + '</div>' +
      '</div>' +
      '<div class="acc-summary-total">' +
        '<div class="amt">' + RN.calc.formatCUP(total) + '</div>' +
        '<div class="lbl">' + RN.render.esc(monedaTxt) + monedaBadge + '</div>' +
      '</div>' +
      '<span class="acc-chevron">▼</span>' +
    '</div>' +
    '<div class="acc-details">' +
      '<div class="acc-row"><span class="acc-label">Fecha</span><span class="acc-value">' + RN.render.esc(fechaTxt) + '</span></div>' +
      '<div class="acc-row"><span class="acc-label">Cliente</span><span class="acc-value">' + nombre + '</span></div>' +
      '<div class="acc-row"><span class="acc-label">Concepto</span><span class="acc-value">' + concepto + '</span></div>' +
      desgloseHtml +
      '<div class="acc-row"><span class="acc-label">Total</span><span class="acc-value"><strong>' + RN.calc.formatCUP(total) + '</strong>' + (h.excedente ? ' <span class="muted" style="font-size:11px">(vuelto ' + RN.calc.formatCUP(h.excedente) + ')</span>' : '') + '</span></div>' +
      '<div class="acc-row"><span class="acc-label">Moneda</span><span class="acc-value">' + RN.render.esc(monedaTxt) + monedaBadge + '</span></div>' +
      '<div class="acc-row"><span class="acc-label">Tipo</span><span class="acc-value">' + tipoBadge + '</span></div>' +
      '<div class="acc-row"><span class="acc-label">Recibo</span><span class="acc-value">' + reciboHtml + '</span></div>' +
    '</div>' +
  '</div>';
};

// v5.13.9 (CODE-7): Construye una cintilla de mes con sus cobros.
RN.render._cintillaMes = function (mesKey, cobros, esPrimera) {
  var totalMes = cobros.reduce(function (s, h) { return s + RN.calc.totalCobro(h); }, 0);
  var nombreMes = mesKey === 'sin-fecha' ? 'Sin fecha' : RN.calc.mesTexto(mesKey);
  var cintillaId = 'cintilla-mes-' + mesKey;
  var abierta = esPrimera ? ' cintilla-mes-open' : '';
  var chevron = esPrimera ? ' ▲' : ' ▼';
  var sq = String.fromCharCode(0x27);

  var cobrosHtml = cobros.map(RN.render._cardCobroRealizado).join('');

  return '<div class="cintilla-mes' + abierta + '" id="' + cintillaId + '">' +
    '<div class="cintilla-mes-head" onclick="RN.render.toggleCintillaMes(' + String.fromCharCode(0x5c) + sq + cintillaId + sq + String.fromCharCode(0x5c) + sq + ')">' +
      '<span class="cintilla-mes-icon">📅</span>' +
      '<div class="cintilla-mes-titulo">' +
        '<div class="cintilla-mes-nombre">' + RN.render.esc(nombreMes) + '</div>' +
        '<div class="cintilla-mes-sub">' + cobros.length + ' cobro' + (cobros.length !== 1 ? 's' : '') + ' · ' + RN.calc.formatCUP(totalMes) + '</div>' +
      '</div>' +
      '<span class="cintilla-mes-chevron">' + chevron + '</span>' +
    '</div>' +
    '<div class="cintilla-mes-body">' + cobrosHtml + '</div>' +
  '</div>';
};

// v5.13.9 (CODE-7/LOG-1): KPIs calculados sobre la lista ya filtrada.
RN.render._kpisRealizados = function (lista) {
  var cont = document.getElementById('kpi-realizados');
  if (!cont) return;
  var total = lista.reduce(function (s, h) { return s + RN.calc.totalCobro(h); }, 0);
  var count = lista.length;
  // v5.13.9 (BUG-2): Ventas de inventario (tipoPago 'completo' por defecto) cuentan como completos
  var completos = lista.filter(function (h) { return (h.tipoPago || 'completo') === 'completo'; }).length;
  var parciales = lista.filter(function (h) { return h.tipoPago === 'parcial'; }).length;
  var excedentes = lista.filter(function (h) { return h.tipoPago === 'excedente'; }).length;
  cont.innerHTML = [
    { label: 'Total cobrado', value: RN.calc.formatCUP(total), cls: 'green' },
    { label: 'Cobros realizados', value: count, cls: 'blue' },
    { label: 'Completos', value: completos, cls: 'green' },
    { label: 'Parciales', value: parciales, cls: 'amber' },
    { label: 'Con excedente', value: excedentes, cls: 'blue' }
  ].map(function (k) { return '<div class="kpi ' + k.cls + '"><div class="label">' + k.label + '</div><div class="value">' + k.value + '</div></div>'; }).join('');
};

// v5.13.9 (CODE-7/LOG-2): Llenar dropdown de meses, reconstruyendo cada vez.
RN.render._fillFiltroMes = function () {
  var selMes = document.getElementById('filtro-realizados-mes');
  if (!selMes) return '';
  // v5.13.9 (LOG-2): Preservar seleccion actual antes de reconstruir
  var mesSelActual = selMes.value || '';
  selMes.innerHTML = '<option value="">Todos los meses</option>';
  var meses = {};
  RN.state.history.forEach(function (h) {
    // v5.13.9 (BUG-3): Usar h.mes (mes de servicio) con fallback a fecha
    var m = h.mes || (h.fecha || '').slice(0, 7);
    if (m) meses[m] = true;
  });
  Object.keys(meses).sort().reverse().forEach(function (m) {
    var opt = document.createElement('option');
    opt.value = m;
    opt.textContent = RN.calc.mesTexto(m);
    selMes.appendChild(opt);
  });
  // Restaurar seleccion si sigue existiendo
  selMes.value = mesSelActual;
  return selMes.value || '';
};

// v5.13.9 (CODE-7): Render principal de la vista Realizados.
RN.render.realizados = function () {
  var listEl = document.getElementById('lista-realizados');
  if (!listEl) return;

  // v5.13.9 (LOG-2/BUG-3): Dropdown se reconstruye cada vez, usa h.mes
  var mesSel = RN.render._fillFiltroMes();
  var q = (document.getElementById('search-realizados') || {}).value || '';
  // v5.13.9 (UI-2): Filtro por tipo de pago
  var tipoSel = (document.getElementById('filtro-realizados-tipo') || {}).value || '';

  // v5.13.9 (CODE-1/BUG-6): Filtrado centralizado con historial.filtrar()
  var lista = RN.historial.filtrar({ mes: mesSel, tipoPago: tipoSel, q: q });

  // v5.13.9 (LOG-1): KPIs sobre la lista filtrada, no sobre todo el historial
  RN.render._kpisRealizados(lista);

  if (!lista.length) {
    listEl.innerHTML = '<div class="acc-empty"><div class="icon">💰</div>No hay cobros que coincidan con el filtro.</div>';
    return;
  }

  // v5.13.9 (BUG-3): Agrupar por mes de servicio (h.mes), fallback a fecha
  var grupos = {};
  var ordenMeses = [];
  lista.forEach(function (h) {
    var mesKey = h.mes || (h.fecha || '').slice(0, 7) || 'sin-fecha';
    if (!grupos[mesKey]) { grupos[mesKey] = []; ordenMeses.push(mesKey); }
    grupos[mesKey].push(h);
  });
  // ordenMeses ya viene ordenado descendente porque lista esta ordenada por fecha desc
  ordenMeses.sort().reverse();

  // v5.13.9 (CODE-7): Construir cintillas usando _cintillaMes()
  var htmlCintillas = ordenMeses.map(function (mesKey, idx) {
    return RN.render._cintillaMes(mesKey, grupos[mesKey], idx === 0);
  }).join('');

  listEl.innerHTML = htmlCintillas;
};

// v5.12.3: Alterna la expansion de una cintilla de mes en el historial de cobros.
RN.render.toggleCintillaMes = function (cintillaId) {
  var el = document.getElementById(cintillaId);
  if (!el) return;
  var isOpen = el.classList.toggle('cintilla-mes-open');
  var chev = el.querySelector('.cintilla-mes-chevron');
  if (chev) chev.textContent = isOpen ? ' ▲' : ' ▼';
};

// v5.13.2: Helper para generar filas de detalle (.acc-row) en las tarjetas
// de inversión. Centraliza el patrón repetido ~20 veces en render.inversion().
//   label: texto de la etiqueta (ya escapado por el llamador)
//   valor: HTML del valor (puede incluir <strong>, <span class="badge">, etc.)
//   opts:  { bold: true, strong: true, color: 'var(--warn)', cond: false }
//     bold   → aplica font-weight:600 a toda la fila
//     strong → envuelve el valor en <strong> (útil para valores planos)
//     color  → style="color:VAR" dentro del <strong>
//     cond   → si es false, devuelve '' (fila omitida). Útil para filas condicionales.
RN.render._filaDetalle = function (label, valor, opts) {
  opts = opts || {};
  if (opts.cond === false) return '';
  var style = opts.bold ? ' style="font-weight:600"' : '';
  var valHtml = valor;
  if (opts.strong) {
    var colorStyle = opts.color ? ' style="color:' + opts.color + '"' : '';
    valHtml = '<strong' + colorStyle + '>' + valor + '</strong>';
  }
  return '<div class="acc-row"' + style + '><span class="acc-label">' + label + '</span><span class="acc-value">' + valHtml + '</span></div>';
};

// ---------- INVERSION ----------
RN.render.inversion = function () {
  const kpi = document.getElementById('kpi-inversion');
  const pctPersonal = RN.investment.pctPersonal();
  // v5.13.2 (fusión visual): KPIs combinados de inversión + deudas en una sola grid.
  if (kpi) {
    var _deudasActivas = RN.investment.deudasActivas();
    var _deudasConcluidas = RN.investment.deudasConcluidas();
    var _saldoDeudas = _deudasActivas.reduce(function (s, i) { return s + RN.investment.saldoADevolver(i); }, 0);
    var _devueltoActivas = _deudasActivas.reduce(function (s, i) { return s + RN.investment.totalDevuelto(i); }, 0);
    var _devueltoConcluidas = _deudasConcluidas.reduce(function (s, i) { return s + RN.investment.totalDevuelto(i); }, 0);
    kpi.innerHTML = [
      { label: 'Total invertido', value: RN.calc.formatCUP(RN.investment.totalInvertido()), cls: 'blue' },
      { label: 'Recuperado (neto)', value: RN.calc.formatCUP(RN.investment.totalRecuperado()), cls: 'green' },
      { label: '% recuperación' + (RN.investment.costoMegaConfigurado() ? '' : ' (estimado)'), value: RN.investment.porcentajeRecuperacion() + '%', cls: 'amber' },
      { label: 'Por recuperar', value: RN.calc.formatCUP(Math.max(0, RN.investment.totalInvertido() - RN.investment.totalRecuperado())), cls: 'red' },
      { label: 'Deudas activas', value: String(_deudasActivas.length), cls: 'blue' },
      { label: 'Saldo por devolver', value: RN.calc.formatCUP(_saldoDeudas), cls: 'red' },
      { label: 'Ya devuelto (activas)', value: RN.calc.formatCUP(_devueltoActivas), cls: 'amber' },
      { label: 'Concluidas', value: String(_deudasConcluidas.length) + ' · ' + RN.calc.formatCUP(_devueltoConcluidas), cls: 'green' }
    ].map(k => '<div class="kpi ' + k.cls + '"><div class="label">' + k.label + '</div><div class="value">' + k.value + '</div></div>').join('');
  }

  // v5.12.6 (propuesta B): barra animada de recuperación global de la inversión.
  // Se muestra solo si hay inversiones registradas (la card viene oculta por defecto).
  const recupInvEl = document.getElementById('inversion-recuperacion');
  const recupInvCard = document.getElementById('card-recuperacion-inv');
  if (recupInvEl && recupInvCard) {
    if (RN.investment.totalInvertido() > 0) {
      recupInvCard.style.display = '';
      recupInvEl.innerHTML = RN.render.barraRecuperacion();
    } else {
      recupInvCard.style.display = 'none';
    }
  }

  const cont = document.getElementById('lista-inversion');
  if (!cont) return;
  if (!RN.state.investments.length) {
    cont.innerHTML = '<div class="acc-empty"><div class="icon">📈</div>No hay inversiones registradas.</div>';
    return;
  }
  // v5.13.3 (fix duplicación): el bloque "Inversiones" solo muestra capital propio.
  // Los préstamos externos (prestado_externo) se muestran en el bloque "Deudas personales activas"
  // con toda su información de recuperación integrada, para evitar duplicados.
  var _inversionesPropias = RN.state.investments.filter(function (inv) {
    return RN.investment.origenCapital(inv) !== 'prestado_externo';
  });
  if (!_inversionesPropias.length) {
    cont.innerHTML = '<div class="acc-empty"><div class="icon">📈</div>No hay inversiones con capital propio registradas.</div>';
  } else {
  cont.innerHTML = _inversionesPropias.map(inv => {
    const recuperado = RN.investment.recuperadoRealInv(inv);
    const pct = inv.monto ? Math.round(recuperado / inv.monto * 100) : 0;
    const dotCls = pct >= 100 ? 'ok' : 'warn';
    const fechaC = RN.investment.fechaCompra(inv);
    const fechaTxt = fechaC ? new Date(fechaC).toLocaleDateString('es-CU') : '<span class="muted">—</span>';
    const dias = RN.investment.diasDesdeCompra(inv);
    const aportes = RN.investment.aportesPorCliente(inv);
    const totalAporteBruto = RN.investment.totalAporteClientes(inv);
    const totalMargenNeto = RN.investment.totalMargenNetoClientes(inv);
    const totalRecuperacion = RN.investment.totalRecuperacionClientes(inv);
    const aporteMesNeto = RN.investment.aporteMensualNeto(inv);
    const acumRetenido = RN.investment.acumuladoRetenido(inv);
    const retiroMes = RN.investment.retiroMensualEstimado(inv);
    const margenMesBruto = RN.investment.margenMensualBruto(inv);
    // v5.12.9: nuevo modelo de origen del capital + devoluciones + aporte extra de ganancia del mes
    const origenCap = RN.investment.origenCapital(inv);
    const origenTxt = RN.investment.origenCapitalTxt(inv);
    const esPrestamo = origenCap === 'prestado_externo';
    const totalDevuelto = RN.investment.totalDevuelto(inv);
    const saldoDevolver = RN.investment.saldoADevolver(inv);
    const recuperadoNeto = RN.investment.recuperadoNetoInv(inv);
    const pctGananciaMes = RN.investment.pctGananciaMes();
    const aporteExtraMes = RN.investment.aporteExtraMes(inv);
    const aporteExtraAcum = RN.investment.aporteExtraAcumulado(inv);
    const recuperadoEfectivo = RN.investment.recuperadoEfectivo(inv);
    const pctEfectivo = inv.monto ? Math.round(recuperadoEfectivo / inv.monto * 100) : 0;
    const aportesHtml = aportes.length ? aportes.map(a => {
      const nom = a.cliente ? RN.render.esc(a.cliente.nombre) : '<span class="muted">— eliminado —</span>';
      const pctCli = inv.monto ? Math.round(a.recuperacion / inv.monto * 100) : 0;
      const signoMargen = a.margenNeto >= 0 ? '' : '<span style="color:#c62828">';
      const cierreSigno = a.margenNeto >= 0 ? '' : '</span>';
      return '<div class="acc-row"><span class="acc-label">' + nom + '<br><span class="muted" style="font-size:11px">Bruto: ' + RN.calc.formatCUP(a.aporte) + ' · Margen neto: ' + signoMargen + RN.calc.formatCUP(a.margenNeto) + cierreSigno + '</span></span><span class="acc-value"><strong>' + RN.calc.formatCUP(a.recuperacion) + '</strong> <span class="muted" style="font-size:11px">(' + pctCli + '%)</span></span></div>';
    }).join('') : '<div class="acc-row"><span class="acc-value muted">Sin clientes vinculados</span></div>';
    return '<div class="acc-card" id="acc-inv-' + inv.id + '">' +
      '<div class="acc-summary" onclick="RN.render.toggleCard(\'acc-inv-' + RN.render.escAttr(inv.id) + '\')">' +
        '<span class="acc-dot ' + dotCls + '"></span>' +
        '<div class="acc-summary-main">' +
          '<div class="acc-summary-name">' + RN.render.esc(inv.concepto) + '</div>' +
          '<div class="acc-summary-sub">' + (esPrestamo ? '💨 Préstamo · debe ' + RN.calc.formatCUP(saldoDevolver) + ' · ' : '') + (inv.clienteIds || []).length + ' clientes vinculados · ' + pct + '% recuperado' + (fechaC ? ' · ' + dias + ' días' : '') + '</div>' +
        '</div>' +
        '<div class="acc-summary-total">' +
          '<div class="amt">' + RN.calc.formatCUP(inv.monto) + '</div>' +
          '<div class="lbl">Invertido</div>' +
        '</div>' +
        '<span class="acc-chevron">▼</span>' +
      '</div>' +
      '<div class="acc-details">' +
        RN.render._filaDetalle('Fecha de compra', fechaTxt) +
        RN.render._filaDetalle('Días transcurridos', (fechaC ? dias + ' días' : '<span class="muted">—</span>')) +
        RN.render._filaDetalle('Monto invertido', RN.calc.formatCUP(inv.monto)) +
        RN.render._filaDetalle('Origen del capital', '<span class="badge ' + (esPrestamo ? 'warn' : 'ok') + '>' + RN.render.esc(origenTxt) + '</span>') +
        RN.render._filaDetalle('Saldo a devolver', RN.calc.formatCUP(saldoDevolver), { strong: true, color: 'var(--warn)', cond: esPrestamo }) +
        RN.render._filaDetalle('Ya devuelto', RN.calc.formatCUP(totalDevuelto), { cond: esPrestamo }) +
        RN.render._filaDetalle('Recuperado neto (− devoluciones)', RN.calc.formatCUP(recuperadoNeto), { cond: esPrestamo }) +
        RN.render._filaDetalle('Pago de la compra (' + inv.monedaPago + ')', RN.moneda.desglosePagoHTML({ moneda: inv.monedaPago, montoUSD: inv.montoPagoUSD, montoPagoCUP: inv.montoPagoCUP, montoPagoCUPDesdeUSD: inv.montoPagoCUPDesdeUSD, totalRecibidoCUP: inv.totalPagoCUP, tasaUsd: inv.tasaUsdCompra }), { cond: !!inv.monedaPago }) +
        RN.render._filaDetalle('Ingreso bruto de clientes', RN.calc.formatCUP(totalAporteBruto)) +
        RN.render._filaDetalle('Margen neto (− costo del mega)', (totalMargenNeto >= 0 ? '' : '<span style="color:#c62828">') + RN.calc.formatCUP(totalMargenNeto) + (totalMargenNeto >= 0 ? '' : '</span>')) +
        RN.render._filaDetalle('Ganancia personal retenida acumulada (' + pctPersonal + '%)', RN.calc.formatCUP(acumRetenido), { cond: pctPersonal > 0 }) +
        RN.render._filaDetalle('Recuperado (neto, automático)', RN.calc.formatCUP(recuperado), { bold: true, strong: true }) +
        RN.render._filaDetalle('% recuperación', '<span class="badge ' + (pct >= 100 ? 'ok' : 'warn') + '>' + pct + '%</span>') +
        RN.render._filaDetalle('Margen neto mensual (bruto)', RN.calc.formatCUP(margenMesBruto)) +
        RN.render._filaDetalle('Disponible para retirar/mes (' + pctPersonal + '% del margen)', RN.calc.formatCUP(retiroMes), { strong: true, color: 'var(--green)', cond: pctPersonal > 0 }) +
        RN.render._filaDetalle('Aporte neto mensual a recuperación', RN.calc.formatCUP(aporteMesNeto)) +
        RN.render._filaDetalle('Aporte extra del mes (' + pctGananciaMes + '% de la ganancia neta)', '+' + RN.calc.formatCUP(aporteExtraMes), { strong: true, color: 'var(--green)', cond: pctGananciaMes > 0 }) +
        RN.render._filaDetalle('Aporte extra acumulado', RN.calc.formatCUP(aporteExtraAcum), { cond: pctGananciaMes > 0 }) +
        RN.render._filaDetalle('Recuperado efectivo (cobrado + aporte extra)', RN.calc.formatCUP(recuperadoEfectivo) + ' <span class="badge ' + (pctEfectivo >= 100 ? 'ok' : 'warn') + '>' + pctEfectivo + '%</span>', { bold: true, strong: true, cond: pctGananciaMes > 0 }) +
        RN.render._filaDetalle('Tiempo restante para recuperar', RN.render.esc(RN.investment.proyectarRecuperacion(inv)), { bold: true, strong: true }) +
        RN.render._filaDetalle('Clientes vinculados', (inv.clienteIds || []).length) +
        '<div class="divider" style="margin:8px 0"></div>' +
        RN.render._filaDetalle('Ganancia real por cliente (recupera el capital)', RN.calc.formatCUP(totalRecuperacion), { bold: true, strong: true }) +
        aportesHtml +
        '<div class="acc-actions">' +
          (esPrestamo
            ? '<button class="btn sm primary" onclick="RN.inversion.devolucionPrestamo(\'' + RN.render.escAttr(inv.id) + '\')">💨 Devolver préstamo</button>' +
              '<button class="btn sm" onclick="RN.inversion.historialDevoluciones(\'' + RN.render.escAttr(inv.id) + '\')">📋 Devoluciones</button>'
            : '') +
          '<button class="btn sm" onclick="RN.inversion.abrirEditar(\'' + RN.render.escAttr(inv.id) + '\')">Editar</button>' +
          '<button class="btn sm danger" onclick="RN.inversion.eliminar(\'' + RN.render.escAttr(inv.id) + '\')">🗑</button>' +
        '</div>' +
      '</div>' +
    '</div>';
  }).join('');
  }

  // v5.12.6: disparar la animación de la barra de recuperación tras pintarla.
  if (typeof requestAnimationFrame === 'function') {
    requestAnimationFrame(RN.render.animarBarrasRecuperacion);
  } else {
    RN.render.animarBarrasRecuperacion();
  }

  // v5.13.2 (fusión visual): renderizar también las listas de deudas
  // (activas y concluidas) dentro de esta misma vista unificada.
  // Los KPIs de deudas ya se integraron arriba en la grid combinada.
  var _act = RN.investment.deudasActivas();
  var _conc = RN.investment.deudasConcluidas();
  RN.inversion._renderDeudasActivas(_act);
  RN.inversion._renderDeudasConcluidas(_conc);
};
// ---------- INVENTARIO ----------
RN.render.inventario = function () {
  const cont = document.getElementById('lista-inventario');
  if (!cont) return;
  // v5.12.0: vista agrupada por producto (material), con lotes FIFO
  var productos = RN.inventarioModel.productosAgrupados();
  if (!productos.length) {
    cont.innerHTML = '<div class="acc-empty"><div class="icon">📦</div>No hay productos en inventario.</div>';
    return;
  }
  // KPI de inventario: valor total del stock, ganancia potencial
  var valorStock = 0, gananciaPotencial = 0;
  productos.forEach(function (p) {
    p.lotes.forEach(function (l) {
      var disp = RN.inventarioModel.stockDisponibleLote(l.id);
      valorStock += disp * (l.costoUnitario || 0);
    });
    var costoVig = p.costoVigente;
    var precioSug = RN.inventarioModel.precioVentaSugerido(costoVig);
    gananciaPotencial += p.stockDisponible * (precioSug - costoVig);
  });
  cont.innerHTML = productos.map(function (p) {
    var dotCls = p.stockDisponible > 0 ? 'ok' : 'due';
    var costoVig = p.costoVigente;
    var precioSug = RN.inventarioModel.precioVentaSugerido(costoVig);
    var pct = RN.inventarioModel.pctGanancia();
    var claveId = 'acc-invprod-' + p.key.replace(/[^a-z0-9]/g, '-');
    // Lotes del producto (ordenados por fecha = FIFO)
    var lotesHtml = p.lotes.map(function (l, idx) {
      var dispLote = RN.inventarioModel.stockDisponibleLote(l.id);
      var esVigente = dispLote > 0 && costoVig === (l.costoUnitario || 0) && idx === p.lotes.findIndex(function (x) { return RN.inventarioModel.stockDisponibleLote(x.id) > 0; });
      var badgeVigente = esVigente ? ' <span class="badge ok">vigente FIFO</span>' : '';
      var badgeAgotado = dispLote === 0 ? ' <span class="badge due">agotado</span>' : '';
      var fechaStr = l.fecha ? new Date(l.fecha).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
      // Asignaciones de este lote
      var asigs = RN.state.asignacionesInventario.filter(function (a) { return a.loteId === l.id; });
      var asigsHtml = asigs.length ? asigs.map(function (a) {
        var cli = RN.state.clients.find(function (c) { return c.id === a.clienteId; });
        var cliNom = cli ? RN.render.esc(cli.nombre) : '<span class="muted">— cliente eliminado —</span>';
        var estado = a.vendida ? '<span class="badge ok">vendida</span>' : '<span class="badge warn">asignada</span>';
        return '<div class="acc-row"><span class="acc-label">' + a.cantidad + ' ud. → ' + cliNom + '</span><span class="acc-value">' + estado + ' ' + RN.calc.formatCUP(a.precioTotal || 0) + '</span></div>';
      }).join('') : '<div class="acc-row"><span class="acc-value muted">Sin asignaciones</span></div>';
      // Desglose de pago del lote (si tiene)
      var pagoHtml = '';
      if (l.monedaPago) {
        pagoHtml = '<div class="acc-row"><span class="acc-label">Pago (' + l.monedaPago + ')</span><span class="acc-value">' + RN.moneda.desglosePagoHTML({
          moneda: l.monedaPago,
          montoUSD: l.montoPagoUSD,
          montoCUP: l.montoPagoCUP,
          montoCUPDesdeUSD: l.montoPagoCUPDesdeUSD,
          totalRecibidoCUP: l.totalPagoCUP,
          tasaUsd: l.tasaUsdCompra
        }) + '</span></div>';
      }
      return '<div style="background:var(--bg-alt);padding:10px 12px;border-radius:8px;margin-bottom:8px">'
        + '<div class="acc-row"><span class="acc-label">Lote ' + (idx + 1) + ' · ' + fechaStr + badgeVigente + badgeAgotado + '</span><span class="acc-value">' + l.cantidad + ' compradas · ' + dispLote + ' disp.</span></div>'
        + '<div class="acc-row"><span class="acc-label">Costo unitario</span><span class="acc-value">' + RN.calc.formatCUP(l.costoUnitario || 0) + '</span></div>'
        + '<div class="acc-row"><span class="acc-label">Costo total</span><span class="acc-value">' + RN.calc.formatCUP(l.costoTotal || (l.cantidad * (l.costoUnitario || 0))) + '</span></div>'
        + (l.notas ? '<div class="acc-row"><span class="acc-label">Notas</span><span class="acc-value">' + RN.render.esc(l.notas) + '</span></div>' : '')
        + pagoHtml
        + '<div class="divider" style="margin:6px 0"></div>'
        + asigsHtml
        + '<div class="acc-actions" style="margin-top:8px">'
        +   '<button class="btn sm" onclick="RN.inventario.eliminarLote(\'' + RN.render.escAttr(l.id) + '\')">🗑 Eliminar lote</button>'
        + '</div>'
        + '</div>';
    }).join('');
    return '<div class="acc-card" id="' + claveId + '">'
      + '<div class="acc-summary" onclick="RN.render.toggleCard(\'' + claveId + '\')">'
      +   '<span class="acc-dot ' + dotCls + '"></span>'
      +   '<div class="acc-summary-main">'
      +     '<div class="acc-summary-name">' + RN.render.esc(p.nombre) + '</div>'
      +     '<div class="acc-summary-sub">' + p.lotes.length + ' lote' + (p.lotes.length > 1 ? 's' : '') + ' · ' + p.stockDisponible + ' disp. · costo vigente ' + RN.calc.formatCUP(costoVig) + '/ud · venta sug. ' + RN.calc.formatCUP(precioSug) + '</div>'
      +   '</div>'
      +   '<div class="acc-summary-total">'
      +     '<div class="amt">' + p.stockDisponible + '</div>'
      +     '<div class="lbl">Disponible</div>'
      +   '</div>'
      +   '<span class="acc-chevron">▼</span>'
      + '</div>'
      + '<div class="acc-details">'
      +   '<div class="acc-row"><span class="acc-label">Producto</span><span class="acc-value">' + RN.render.esc(p.nombre) + '</span></div>'
      +   '<div class="acc-row"><span class="acc-label">Stock total comprado</span><span class="acc-value">' + p.stockTotal + ' ud.</span></div>'
      +   '<div class="acc-row"><span class="acc-label">Stock disponible</span><span class="acc-value"><span class="badge ' + (p.stockDisponible > 0 ? 'ok' : 'due') + '">' + p.stockDisponible + '</span></span></div>'
      +   '<div class="acc-row"><span class="acc-label">Costo vigente (FIFO)</span><span class="acc-value">' + RN.calc.formatCUP(costoVig) + '/ud</span></div>'
      +   '<div class="acc-row"><span class="acc-label">Precio de venta sugerido (' + pct + '%)</span><span class="acc-value"><strong>' + RN.calc.formatCUP(precioSug) + '/ud</strong></span></div>'
      +   '<div class="acc-row"><span class="acc-label">Ganancia potencial</span><span class="acc-value" style="color:var(--green)">' + RN.calc.formatCUP(p.stockDisponible * (precioSug - costoVig)) + '</span></div>'
      +   '<div class="divider" style="margin:8px 0"></div>'
      +   '<div class="acc-row" style="font-weight:600"><span class="acc-label">Lotes (' + p.lotes.length + ') — FIFO (más antiguo primero)</span></div>'
      +   lotesHtml
      +   '<div class="acc-actions">'
      +     '<button class="btn sm primary" onclick="RN.inventario.asignar(\'' + RN.render.escAttr(p.nombre) + '\')">Asignar / vender</button>'
      +     '<button class="btn sm" onclick="RN.inventario.abrirNuevoLote(\'' + RN.render.escAttr(p.nombre) + '\')">📋 Comprar más</button>'
      +   '</div>'
      + '</div>'
      + '</div>';
  }).join('');
};
// ---------- GASTOS ----------
RN.render.gastos = function () {
  const kpi = document.getElementById('kpi-gastos');
  if (kpi) {
    const total = RN.calc.gastosTotales();
    kpi.innerHTML = [
      { label: 'Gastos totales', value: RN.calc.formatCUP(total), cls: 'red' },
      { label: 'Gastos del mes', value: RN.calc.formatCUP(RN.calc.gastosMes()), cls: 'amber' }
    ].map(k => '<div class="kpi ' + k.cls + '"><div class="label">' + k.label + '</div><div class="value">' + k.value + '</div></div>').join('');
  }
  const cont = document.getElementById('lista-gastos');
  if (!cont) return;
  if (!RN.state.gastos.length) {
    cont.innerHTML = '<div class="acc-empty"><div class="icon">💸</div>No hay gastos registrados.</div>';
    return;
  }
  const gastos = [...RN.state.gastos].sort((a, b) => (b.fecha || '').localeCompare(a.fecha || ''));
  cont.innerHTML = gastos.map(g => {
    var catBadge = '<span class="pill">' + RN.render.esc(g.categoria || 'General') + '</span>';
    var provIcon = g.esPagoProveedor ? ' 📡' : '';
    var retiroIcon = g.esRetiroCaja ? ' 💵' : '';
    var retiroBadge = g.esRetiroCaja ? '<span class="badge warn" style="margin-left:4px">Retiro de caja</span>' : '';
    return '<div class="acc-card" id="acc-gas-' + g.id + '">' +
      '<div class="acc-summary" onclick="RN.render.toggleCard(\'acc-gas-' + g.id + '\')">' +
        '<span class="acc-dot due"></span>' +
        '<div class="acc-summary-main">' +
          '<div class="acc-summary-name">' + RN.render.esc(g.concepto) + provIcon + retiroIcon + '</div>' +
          '<div class="acc-summary-sub">' + RN.render.esc((g.fecha || '').slice(0, 10)) + ' · ' + RN.render.esc(g.categoria || 'General') + '</div>' +
        '</div>' +
        '<div class="acc-summary-total">' +
          '<div class="amt">' + RN.calc.formatCUP(g.monto) + '</div>' +
          '<div class="lbl">Gasto</div>' +
        '</div>' +
        '<span class="acc-chevron">▼</span>' +
      '</div>' +
      '<div class="acc-details">' +
        '<div class="acc-row"><span class="acc-label">Fecha</span><span class="acc-value">' + RN.render.esc((g.fecha || '').slice(0, 10)) + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Concepto</span><span class="acc-value">' + RN.render.esc(g.concepto) + provIcon + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Categoría</span><span class="acc-value">' + catBadge + retiroBadge + '</span></div>' +
        '<div class="acc-row"><span class="acc-label">Monto</span><span class="acc-value">' + RN.calc.formatCUP(g.monto) + '</span></div>' +
        '<div class="acc-actions">' +
          '<button class="btn sm danger" onclick="RN.gastos.eliminar(\'' + g.id + '\')">🗑</button>' +
        '</div>' +
      '</div>' +
    '</div>';
  }).join('');
};
// ---------- REPORTES ----------
RN.render.reportes = function () {
  const kpi = document.getElementById('kpi-reportes');
  if (kpi) {
    kpi.innerHTML = [
      { label: 'Ingresos totales', value: RN.calc.formatCUP(RN.calc.ingresosTotales()), cls: 'green' },
      { label: 'Gastos totales', value: RN.calc.formatCUP(RN.calc.gastosTotales()), cls: 'red' },
      { label: 'Utilidad acumulada', value: RN.calc.formatCUP(RN.calc.ingresosTotales() - RN.calc.gastosTotales()), cls: 'blue' },
      { label: 'Predicción próximo mes', value: RN.calc.formatCUP(RN.calc.prediccionIngresos()), cls: 'amber' }
    ].map(k => `<div class="kpi ${k.cls}"><div class="label">${k.label}</div><div class="value">${k.value}</div></div>`).join('');
  }

  // Historial
  const tbody = document.querySelector('#tabla-historial tbody');
  if (tbody) {
    if (!RN.state.history.length) {
      tbody.innerHTML = `<tr><td colspan="5"><div class="empty">Sin cobros registrados todavía.</div></td></tr>`;
    } else {
      const hist = [...RN.state.history].sort((a, b) => (b.fecha || '').localeCompare(a.fecha || '')).slice(0, 50);
      tbody.innerHTML = hist.map(h => {
        const cli = RN.calc.clientePorId(h.clienteId);
        const total = RN.calc.totalCobro(h);
        var monedaBadge = '';
        if (h.moneda === 'MIXTO' && h.montoPagadoUSD > 0 && h.montoPagadoCUP > 0) {
          monedaBadge = ` <span class="pill" style="background:#e8f5e9;color:#2e7d32">USD ${h.montoPagadoUSD} + CUP ${h.montoPagadoCUP}</span>`;
        } else if (h.moneda === 'USD' && h.montoPagadoUSD > 0) {
          monedaBadge = ` <span class="pill" style="background:#e8f5e9;color:#2e7d32">USD ${h.montoPagadoUSD}</span>`;
        } else if (h.montoPagadoUSD > 0 && h.montoPagadoCUP > 0) {
          monedaBadge = ` <span class="pill" style="background:#e8f5e9;color:#2e7d32">USD ${h.montoPagadoUSD} + CUP ${h.montoPagadoCUP}</span>`;
        }
        // v5.13.9 (DUP-2): Usar badge unificado
        const tipoBadge = RN.render.badgeTipoPago(h);
        return `<tr>
          <td data-label="Fecha">${RN.render.esc((h.fecha || '').slice(0, 10))}</td>
          <td data-label="Cliente">${RN.render.esc(cli ? cli.nombre : (h.ventaInventario ? 'Venta inventario' : '—'))}</td>
          <td data-label="Concepto">${h.tipo === 'servicio' ? 'Servicio ' + (h.mes ? RN.calc.mesTexto(h.mes) : '') : (h.tipo === 'equipo' ? 'Cuota equipo' : RN.render.esc(h.concepto || h.tipo))}</td>
          <td data-label="Monto">${RN.calc.formatCUP(total)}${monedaBadge}${tipoBadge}</td>
          <td data-label="Recibo">${h.reciboNum ? `<button class="btn sm" onclick="RN.recibo.ver('${RN.render.escAttr(h.id)}')">${h.reciboNum}</button>` : '—'}</td>
        </tr>`;
      }).join('');
    }
  }

  // Tendencia (chart simple con barras div)
  RN.tendencia && RN.tendencia.render();

  // Selector de mes para reporte mensual
  const sel = document.getElementById('select-mes-reporte');
  if (sel) {
    const meses = [];
    let m = RN.calc.mesActualStr();
    for (let i = 0; i < 12; i++) { meses.push(m); m = RN.calc.mesAnterior(m); }
    sel.innerHTML = meses.map(m => `<option value="${m}">${RN.calc.mesTexto(m)}</option>`).join('');
  }
};
