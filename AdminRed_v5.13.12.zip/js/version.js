/**
 * version.js — Fuente única de verdad de la versión de la app.
 * Sin dependencias. Debe cargarse PRIMERO, antes que todo (incluido sw.js).
 * Cada cambio publicado debe subir APP_VERSION para invalidar la caché del SW.
 */
const APP_VERSION = '5.13.12';
const APP_NAME = 'AdminRed';
const APP_CODENAME = 'RedNet';
